/*
 * WEEshop app ENGINE v 1.7a: light weight ecomerce.
 *
 * Requires either jQuery or YUI3.
 *
 * Copyright (c) 2014-2016 Weeble Group. All rights reserved. For license, see "README" or "LICENSE" file.
 * Commerce license: vip-velik.ru.
 * @author info@weeble.pro April 2016
 *
 */
(function() {
  "use strict";
	var JSONData, // Массив товаров
		cart, // Массив id товаров
		counter=$(".badge.badge-sea.rounded-x"),
		cartList;	
	var products=[]; // products array
	var id,qty,size,color,item; // products parametrs
	var img,span,div,li,btn,small,docfrag; // elements for render
	var myExp,search; // renderInfo vars
	function cartCount() {
		counter.html( $('#mCSB_1_container li').length );
	}
	function overDel () {
			setTimeout(function(){
				$('#loading').addClass('animated fadeOut');
				setTimeout(function() {	$('#loading').remove();}, 600);
			},2300);
		}
	var shop = {
		/* WEETRIX ENGINE CALLBACKS */
		Init: function () {
			cartCount();
			shop.JSONData(); // получение списка товаров
			shop.btnClose(); // инициализация кнопок удаления из корзины
			shop.btnCart();	 // инициализация кнопки в корзину
			VK.Widgets.Group("vk_groups", {mode: 3, width: "auto"}, 124161875);
			overDel(); // удаляем Loader overlay
			shop.initScrollBar();
			shop.getLsProducts();  // Берем все товары из корзины
			shop.cartProductRender();//Рисуем список товаров в корзине
		},
        initScrollBar: function () {
            jQuery('.mCustomScrollbar').mCustomScrollbar({
                theme:"minimal",
                scrollInertia: 300,
                scrollEasing: "linear"
            });
        },
		/* WEETRIX SEARCH ENGINE INITIALIZATION */
		btnClose: function() {
			$(".list-unstyled.mCustomScrollbar li .close").click(function(){ // кнопка удаления товара х
			    $(this).parent().remove(); // Remove item from Cart
				cartCount(); // Изменение количества товаров
			});
		},
		setItemParam: function() {
			console.log(products);
				id=search;
				qty=$( "input[name='qty']" ).val();
				size=$( "input[name='size']:checked" ).val();
				color=$( "input[name='color']:checked" ).val();
				if (qty===undefined) {
					qty=1;
				}
				if (size===undefined) {
					size=1;
				}
				if (color===undefined) {
					color=1;
				}
				item={"id":id,"size":size,"qty":qty,"color":color};				
				console.log(item);
		},
		getLsProducts: function() {
			var LSproducts=localStorage.getItem("cart");
			products=JSON.parse(LSproducts);
			console.log(products)
		},
		storeLsProducts: function() {			
			if (products === null) {
				products=[];
			}
			products.push(item);
			localStorage.setItem("cart", JSON.stringify(products));
		},
		localStorage: function (search) {
			shop.setItemParam();	//Выставляем параметры выбранного товара
			shop.getLsProducts();  // Берем все товары из корзины
			shop.storeLsProducts(); // Добавляем товар и записываем в localStorage
			shop.cartProductRender();//Рисуем список товаров в корзине
		},
		btnCart: function() { // handle В КОРЗИНУ btn		
			$('.addProduct').click(
				function(){
					event.preventDefault();
					search = $(this).data('id');
					shop.localStorage();					
				}
			);
		},
		clearCart: function (search) {
			$('#clearCart').click(
				function(){
					products=[];
					localStorage.setItem("cart", JSON.stringify(products));
					shop.cartProductRender();		
				}
			);
		},
		cartProductRender: function  (){
			var cartList=document.getElementById('mCSB_1_container');	
			docfrag = document.createDocumentFragment();
			/* Render service info in modal*/
			function RenderInfo (val,key){				
				li = document.createElement("li");
				li.setAttribute("id", key);
				img = document.createElement("img");
				img.className = "mCS_img_loaded";
				img.setAttribute('src', val.img.thumb);
				console.log(img.src);
				img.setAttribute ('alt', val.model);
				btn=document.createElement("button");
				btn.setAttribute("type","button");
				btn.className="close";
				btn.textContent="×";
				div = document.createElement("div")
				div.className="overflow-h";
				span = document.createElement("span");
				span.textContent=val.brand + ' ' + val.model;
				small = document.createElement("small");
				small.textContent=val.price;
				li.appendChild(img);
				li.appendChild(btn);
				div.appendChild(span);
				div.appendChild(small);
				li.appendChild(div);
			}
			$.each(products, function(key, val) {
				myExp = new RegExp(val['id'], "i");
				$.each(JSONData, function(key, val) {
					if ((key.search(myExp) != -1)) {
						console.log('ИД товара:' + key + '  ');
						console.log(val);
						RenderInfo (val,key);
					}
				});
				docfrag.appendChild(li);
			});
			
			while (cartList.firstChild) {
			    cartList.removeChild(cartList.firstChild);
			}
			cartList.appendChild(docfrag);
			shop.btnClose();
			cartCount();
		},

	    JSONData: function(){
	     	var Now = new Date();
			Now = Now.getTime();
	     	var file = ('data.json?' + Now);
	     	$.getJSON(file, function(data) {
	     		JSONData=data;
	     	});
	    }
		/* WEETRIX HOVER ANIMATION INITIALIZATION */
	}
	jQuery(document).ready(shop.Init); /*INITIALIZATION*/
}());
